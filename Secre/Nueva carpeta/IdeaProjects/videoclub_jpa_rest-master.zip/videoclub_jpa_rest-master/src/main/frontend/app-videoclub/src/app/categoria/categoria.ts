export interface Categoria {

  id: number;

  nombre: string;

  ultimaActualizacion: string

}
